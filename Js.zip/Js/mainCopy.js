//let, const  --->have a block level scope

//Strings, Numbers, Boolean, null, undefined, symbols

// const name = "john";
// const age = 30;
// const isCool = true;
// const rating = 4.5;
// const x = null;
// const y = undefined;
// let z;
// console.log(typeof z);

//Strings
// const name = "john";
// const age = 30;

// //Concatenation
// console.log("My name is " + name + " and I am " + age);

// //Template Strings
// console.log(`My name is ${name} and I am ${age}`);

// const s = "Hello World";
// console.log(s.substring(0, 5).toUpperCase());

// const s = "technology,computers,it,code";
// console.log(s.split(","));

//Arrays - variables that hold multiple values

/*multi 
line 
comments */

// const nums = new Array(1, 2, 3, 4, 5, 6);
// const fruits = ["Apples,mangoes,oranges,pears", 10, true];
// const fruits = ["Apples", "oranges", "mangoes"];
//console.log(fruits[1]);
// fruits[2] = "grapes";
// fruits.push("mangos");
// fruits.unshift("strawberries");
// fruits.pop();
// console.log(Array.isArray("hello"));
// console.log(fruits.indexOf("oranges"));
// console.log(fruits);

// const person = {
// 	firstName: "John",
// 	lastName: "Doe",
// 	age: 30,
// 	hobbies: ["music", "sports"],
// 	address: {
// 		street: "50 main st",
// 		City: "boston",
// 		state: "ma",
// 	},
// };

// console.log(person.firstName, person.lastName);
// console.log(person.hobbies[1]);
// console.log(person.address.City);

// const {
// 	firstName,
// 	lastName,
// 	address: { City },
// } = person;
// console.log(City);

// person.email = "john@gmail.com";
// console.log(person.email);

// const todos = [
// 	{
// 		id: 1,
// 		text: "Take out trash",
// 		isCompleted: true,
// 	},
// 	{
// 		id: 2,
// 		text: "Meeting with boss",
// 		isCompleted: true,
// 	},
// 	{
// 		id: 3,
// 		text: "Dentist appt",
// 		isCompleted: false,
// 	},
// ];

// console.log(todos);
// console.log(todos[1].text);

// const todoJSON = JSON.stringify(todos);
// console.log(todoJSON);

//For Loops

// for (let i = 0; i <= 10; i++) {
// 	console.log(`For loop number : ${i}`);
// }

//while
// let i = 0;
// while (i <= 5) {
// 	console.log(`While Loop Number : ${i}`);
//     i++;
// }

// for (let i = 0; i < todos.length; i++) {
// 	console.log(todos[i].text);
// }

// for (let todo of todos) {
// 	console.log(todo.id);
// }

//High model iteration
//forEach, map, filter

// todos.forEach(function (todo) {
// 	console.log(todo.text);
// });

//Map
// const todoText = todos.map(function (todo) {
// 	return todo.text;
// });

// console.log(todoText);
//filter

// const todoCompleted = todos
// 	.filter(function (todo) {
// 		return todo.isCompleted === true;
// 	})
// 	.map(function (todo) {
// 		return todo.text;
// 	});

// console.log(todoCompleted);

// const x = 5;
// const y = 11;
// if (x > 5 && y > 10) {
// 	console.log("X is more than 5 or y is more than 10");
// } else if (x > 10) {
// 	console.log("X is greater than to 10");
// } else {
// 	console.log("X less than 10");
// }

// if(x>5){
//     if(y>10)
// }

//Ternary operator

// const x = 11;
// const color = x > 10 ? "red" : "yellow";
// console.log(color);

//Switches

// const x = 9;
// const color = x > 10 ? "red" : "yellow";
// switch (color) {
// 	case "red":
// 		console.log("color is red");
// 		break;
// 	case "yellow":
// 		console.log("color is yellow");
// 		break;
// 	default:
// 		console.log("color os not red or yellow");
// 		break;
// }

//Functions

// function addNums(num1 = 1, num2 = 2) {
// 	return num1 + num2;
// }

// console.log(addNums(5, 5));

//NaN not a number

// const addNums = (num1 = 1, num2 = 2) => {
// 	return num1 + num2;
// };
// console.log(addNums(5, 5));

// const addNums = (num1 = 1, num2 = 1) => console.log(num1 + num2);

// const addNums = (num1 = 1, num2 = 1) => {
// 	return num1 + num2;
// };

// console.log(addNums(5, 5));

// const addNums = (num1) => num1 + 5;

// console.log(addNums(5));

//Constructor Functions
// function Person(firstName, lastName, dob) {
// 	this.firstName = firstName;
// 	this.lastName = lastName;
// 	this.dob = new Date(dob);
// }

// Person.prototype.getBirthYear = function () {
// 	return this.dob.getFullYear();
// };

// Person.prototype.getFullName = function () {
// 	return `${this.firstName} ${this.lastName}`;
// };

//Class

// class Person {
// 	constructor(firstName, lastName, dob) {
// 		this.firstName = firstName;
// 		this.lastName = lastName;
// 		this.dob = new Date(dob);
// 	}
// 	getBirthYear() {
// 		return this.dob.getFullYear();
// 	}
// 	getFullName() {
// 		return `${this.firstName} ${this.lastName}`;
// 	}
// }

// //Instantiate object
// const person1 = new Person("John", "Doe", "4-3-1980");
// const person2 = new Person("Marry", "Smith", "4-4-1986");
// // console.log(person2.dob.getFullYear());

// console.log(person2.getBirthYear());
// console.log(person2.getFullName());
// console.log(person1);



